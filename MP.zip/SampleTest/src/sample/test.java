package sample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class test {
	private static String filePath;
	private static String fileName;
	private static String datasheetName;
	private static FileInputStream fileInputStream;
	private static XSSFWorkbook workbook;
	private static boolean browserConfigAccess;
	private static List<Map<String, String>> values;
	private static String[] testConfigs;
	public static void main(String args[])
	{

		
		//System.out.println("It is working");
		filePath = "C:\\Eclipse Workspace\\SampleTest";
		fileName = "Run Manager";
		datasheetName = "TestConfigurations";
		String browserConfig =  "PerfectoWeb" ;
		String[] keys =  {"TestConfigurationID", "ExecutionMode",
				"MobileToolName", "MobileExecutionPlatform", "MobileOSVersion",
				"DeviceName", "Browser", "BrowserVersion", "Platform"};				
		browserConfigAccess = true;
		String[] testConfig = getTestConfig(keys,browserConfig,browserConfigAccess);
		for (int z=0;z<testConfig.length;z++)
		{
			System.out.println(testConfig[z]);
		}
		String browserConfig1 =  "AppiumNativeAndroid" ;
		String[] testConfig1 = getTestConfig(keys,browserConfig1,browserConfigAccess);
		for (int z=0;z<testConfig1.length;z++)
		{
			System.out.println(testConfig[z]);
		}
	}
	
	public static int getRowNum(String key, int columnNum, int startRowNum) {
		
		XSSFWorkbook workbook = openFileForReading();
		XSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();

		String currentValue;
		for (int currentRowNum = startRowNum; currentRowNum <= worksheet.getLastRowNum(); currentRowNum++) {

			XSSFRow row = worksheet.getRow(currentRowNum);
			XSSFCell cell = row.getCell(columnNum);
			currentValue = getCellValueAsString(cell, formulaEvaluator);

			if (currentValue.equals(key)) {
				return currentRowNum;
			}
		}

		return -1;
	}
	
	private static XSSFWorkbook openFileForReading() {

		String absoluteFilePath = filePath + "\\"+ fileName + ".xlsm";
		
		try {
			fileInputStream = new FileInputStream(absoluteFilePath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		}

		
		try {
			workbook = new XSSFWorkbook(fileInputStream);
			// fileInputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return workbook;
	}


	private static XSSFSheet getWorkSheet(XSSFWorkbook workbook) {
		XSSFSheet worksheet = workbook.getSheet(datasheetName);
		if (worksheet == null) {
		return null;	
		}

		return worksheet;
	}

	private static String getCellValueAsString(XSSFCell cell,
			FormulaEvaluator formulaEvaluator) {
		if (cell == null || cell.getCellType() == XSSFCell.CELL_TYPE_BLANK) {
			return "";
		} else {
			if (formulaEvaluator.evaluate(cell).getCellType() == XSSFCell.CELL_TYPE_ERROR) {
			
			}

			DataFormatter dataFormatter = new DataFormatter();
			return dataFormatter.formatCellValue(formulaEvaluator
					.evaluateInCell(cell));
		}
	}
	
	public static String[] getTestConfig(String[] keys,String browserConfig, Boolean browserConfigAccess) {
		String [] testConfigs_s= null;
		if(browserConfigAccess)
		{
			values = getValues(keys);
			browserConfigAccess = false;
		}
		for(int i = 0; i< values.size();i++)
		{ 
			if(values.get(i).get(keys[0]).equalsIgnoreCase(browserConfig))
			{
				for (int j = 0; j<keys.length;j++)
				{
					//System.out.println(values.get(i).get(keys[j]));
					//testConfigs_s[j] = values.get(i).get(keys[j]);
					System.out.println(keys[j]+"------>"+values.get(i).get(keys[j]));
				}
				break;
			}
		}
		return null;
		
		
		
	}
	
	
	
	
	
	public static List<Map<String, String>> getValues(String[] keys) {
		XSSFWorkbook workbook = openFileForReading();
		XSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator = workbook.getCreationHelper()
				.createFormulaEvaluator();

		XSSFRow hrow = worksheet.getRow(0);
		List<Map<String, String>> values = new ArrayList<Map<String, String>>();
		System.out.println(worksheet.getLastRowNum());
		for (int i = 1; i <= worksheet.getLastRowNum(); i++) {
			Map<String, String> valueMap = new HashMap<String, String>();
			XSSFRow row = worksheet.getRow(i);
			for (int j = 0; j < keys.length; j++) {
				String value = getValue(hrow, row, keys[j], formulaEvaluator);
				valueMap.put(keys[j], value);
			}
			values.add(valueMap);
		}

		return values;
	}
	private static String getValue(XSSFRow hrow, XSSFRow row, String columnHeader,
			FormulaEvaluator formulaEvaluator, int length) {
		int columnNum = -1;
		String currentValue;

		for (int currentColumnNum = 0; currentColumnNum < length; currentColumnNum++) {
			XSSFCell cell = hrow.getCell(currentColumnNum);

			currentValue = getCellValueAsString(cell, formulaEvaluator);

			if (currentValue.equals(columnHeader)) {
				columnNum = currentColumnNum;
				break;
			}
		}

		if (columnNum == -1) 
		{
			return null;
			
		} else {

			XSSFCell cell = row.getCell(columnNum);
			return getCellValueAsString(cell, formulaEvaluator);
		}
	}

	private static String getValue(XSSFRow hrow, XSSFRow row, String columnHeader,
			FormulaEvaluator formulaEvaluator) {
		int columnNum = -1;
		String currentValue;

		for (int currentColumnNum = 0; currentColumnNum < row.getLastCellNum(); currentColumnNum++) {
			XSSFCell cell = hrow.getCell(currentColumnNum);

			currentValue = getCellValueAsString(cell, formulaEvaluator);

			if (currentValue.equals(columnHeader)) {
				columnNum = currentColumnNum;
				break;
			}
		}

		if (columnNum == -1) {
			return null;
		} else {

			XSSFCell cell = row.getCell(columnNum);
			return getCellValueAsString(cell, formulaEvaluator);
		}
	}

	}

